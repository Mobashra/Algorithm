#!/usr/bin/env python
# coding: utf-8

# In[13]:


import task1
visited = [0]*task1.total_node
printed = []

def DFS_VISIT(graph,node):
    visited[int(node)-1] = 1
    printed.append(node)
    
    for each_node in graph[node]:
        if each_node not in visited:
            DFS_VISIT(graph,each_node)
    
    return printed
            
def DFS(graph,end_point):
    output_file = open("output3.txt","w")
    output_file.write("Places: ")
    dfs_list = []
    
    for node in graph:
        if node not in visited:
            dfs_list = DFS_VISIT(graph,node)
            
    for i in range(len(bfs_list)):
        if str(dfs_list[i]) == end_point:
            output_file.write(str(dfs_list[i]) + " ")
            break
        else:
            output_file.write(str(dfs_list[i]) + " ")

DFS(task1.graph,"12")

