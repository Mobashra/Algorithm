#!/usr/bin/env python
# coding: utf-8

# In[3]:


graph = {}
input_array = []

input_file = open("input1.txt","r")
for j in input_file:
    input_array.append(j.split())

for i in input_array[1:]:
    index = int(i[0])
    value = i[1:]
    
    for i,j in enumerate(value):
        value[i] = int(j)
    
    graph[index] = value
    
total_node = int(input_array[0][0])    
input_file.close()


# In[ ]:




