#!/usr/bin/env python
# coding: utf-8

# In[2]:


import task1

def BFS(visited,graph,node,end_point):
    
    output_file = open("output2.txt","w")
    output_file.write("Places: ")
    
    queue = []
    visited[int(node)-1] = 1
    queue.append(node)
    while len(queue) != 0:
        m = queue.pop(0)
        output_file.write(str(m) + " ")
        
        if int(m) == int(end_point):
            break
        
        for neighbour in graph[int(m)]:
            if visited[int(neighbour)-1] == 0:
                visited[int(neighbour)-1] = 1
                queue.append(neighbour)

BFS([0]*task1.total_node,task1.graph,"1","12")

