
def bubbleSort(array):
    
    length = len(array)
    
    for i in range(length-1):
        
        boolean = False
        
        for j in range(length-i-1):
            
            if array[j+1] < array[j]:
                
                temp = array[j+1]
                array[j+1] = array[j]
                array[j] = temp
                
                boolean = True
        
        if boolean is False:
            break
    return array
            
file_input = open("input1.txt","r")
file_output = open("output1.txt","w")

array2 = []
for i in file_input:
    array2 += [i] 

element = array2[1].split(" ")

j = 0
while j < len(element):
    element[j] = int(element[j])
    j += 1

sorted_array = bubbleSort(element)

for i in sorted_array:
    file_output.write(str(i) + " ")
        
file_input.close()
file_output.close()

# Initially for the given code, the time complexity was θ(n^2) beacause of the two nested for loops.
# The time complexity can be made θ(n) if the given array is already sorted.
# This is the optimised bubble sort which gives the best case. 






