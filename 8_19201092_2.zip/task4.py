
def merge_Sort(a):
    if len(a) == 1:
        return a
    else:
        m = int(len(a) / 2)
        a1 = merge_Sort(a[:m])
        a2 = merge_Sort(a[m:])
        array = []
        i = 0
        j = 0
        for a in range(len(a)):
            if a1[i] < a2[j]:
                array.append(a1[i])
                i += 1
            elif a1[i] > a2[j]:
                array.append(a2[j])
                j += 1
            else:
                array.append(a1[i])
                i += 1
                array.append(a2[j])
                j += 1
            if i >= len(a1):
                array += a2[j:]
                break
            elif j >= len(a2):
                array += a1[i:]
                break
        return array

file_input = open("input4.txt", "r")
file_output = open("output4.txt", "w")

array2 = []
for i in file_input:
    array2 += [i]

element = array2[1].split(" ")

j = 0
while j < len(element):
    element[j] = int(element[j])
    j += 1

sorted_array = merge_Sort(element)

for i in sorted_array:
    file_output.write(str(i) + " ")

file_input.close()
file_output.close()

