
def Selection_Sort(array):
   
    for i in range(len(array)):
        
        minimum = i
        j = i+1
        
        while j < len(array):
            if int(array[minimum]) > int(array[j]):
                minimum = j
            j += 1
      
        temp = array[i]
        array[i] = array[minimum]
        array[minimum] = temp
    
    return array

file_input = open("input2.txt","r")
file_output = open("output2.txt","w")

array2 = []
for i in file_input:
    array2 += [i]

element = array2[0].split(" ")
counter = int(element[1].replace("\n",""))
element = array2[1].split(" ")

sorted_array = Selection_Sort(element)

for i in range(counter):
    file_output.write(str(sorted_array[i]) + " ")
    
file_input.close()
file_output.close()





