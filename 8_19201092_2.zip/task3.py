

def insertionSort(array):
    i = 0
    while i < len(array) - 1:
        temp = array[i + 1]

        i2 = i
        while i2 >= 0:
            if array[i2] > temp:
                array[i2 + 1] = array[i2]
            else:
                break
            i2 -= 1
        array[i2 + 1] = temp
        i += 1
    return array

file_input = open("input3.txt", "r")
line = file_input.readline()
file_output = open("output3.txt", "w")

sID = file_input.readline().split()
a = file_input.readline().split()
aList = [int(item) for item in a]
bList = aList.copy()
cList = [int(item) for item in sID]
new_arr = insertionSort(aList)

sID = []
i = len(new_arr) - 1
while i >= 0:
    j = 0
    while j < len(new_arr):
        if new_arr[i] == bList[j]:
            index = j
            sID.append(cList[index])
            bList[j] = 0
        j += 1
    i -= 1

i = 0
while i < len(sID):
    file_output.write(str(sID[i]) + " ")
    i += 1
file_output.write("\n")

file_input.close()
file_output.close()





