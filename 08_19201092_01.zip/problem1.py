#!/usr/bin/env python
# coding: utf-8

# In[39]:


#Name : Mobashra Abeer
# ID : 19201092, Section: 08

#Parity checker function
def isParity(number):

    if "." in number:
        text_back = str(float(number)) + " cannot have parity and "
        return text_back
    
    if int(number) %2 == 0:
        return number + " has even parity and "
    
    if int(number) %2 != 0:
        return number + " has odd parity and "

#Palindrome Function
def isPalindrome(word):
    if word == None:
        return word + " is not a palindrome\n"
    
    for i in range(len(word)//2):
        if word[i] != word[len(word)-1-i]:
            return word + " is not a palindrome\n"

    return word + " is a palindrome\n"


file_input = open("input.txt", "r")
a = []
for i in file_input:
    a.append(i)
    
file_output = open("output.txt", "w")
file_record = open("record.txt", "w")

even_count = 0
odd_count = 0
no_parity_count = 0
palindrome_count = 0
nonpalindrome_count = 0

for i in a:
    input_splitter = i.split(" ")
    number = input_splitter[0]
    word = input_splitter[1]
    parity_checker = isParity(number)
    palindrome_checker = isPalindrome((word.split("\n")[0]))

    if "even parity" in parity_checker:
        even_count += 1
    elif "odd parity" in parity_checker:
        odd_count += 1
    elif "cannot" in parity_checker:
        no_parity_count += 1
    if "is a palindrome" in palindrome_checker:
        palindrome_count += 1
    elif "not a palindrome" in palindrome_checker:
        nonpalindrome_count += 1
        
    file_output.write(str(parity_checker) + str(palindrome_checker))

odd_percentage = (odd_count/len(a))* 100
even_percentage = (even_count/len(a))* 100
no_parity_percentage = (no_parity_count/len(a))* 100
palindrome_percentage = (palindrome_count/len(a))* 100
nonpalindrome_percentage = (nonpalindrome_count/len(a))* 100

file_record.write("Percentage of odd parity: {}%\nPercentage of even parity: {}%\nPercentage of no parity: {}%\nPercentage of palindrome: {}%\nPercentage of non-palindrome: {}%".format(odd_percentage,even_percentage,no_parity_percentage,palindrome_percentage,nonpalindrome_percentage))
             
                  
file_input.close()
file_output.close()
file_record.close()                  

