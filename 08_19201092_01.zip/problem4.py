#!/usr/bin/env python
# coding: utf-8

# In[12]:


def matrix_multiplication(num,A,B):
    C = [[0 for i in range(num)] for j in range(num)]
 
    for i in range(num):
        for j in range(num):
            for k in range(num):
                C[i][j] += A[i][k] * B[k][j]
                
    text = open("C:\\Users\\Abeer\\output4.txt", "w") 
    for i in range(num):
        for j in range(num):
            text.write(str(C[i][j])+" ")
        text.write("\n")
    text.close()

input4 = open("C:\\Users\\Abeer\\input4.txt","r")
num = int(input4.read(1))
arr = []
file = input4.read().splitlines()
for i in file:
    if i != "":
        arr.append(i.split(' '))
        
M=arr[:num]
N=arr[num:]
A=[]
B=[]
for i in M:
    i=list(map(int, i))
    A.append(i)
for i in N:    
    i=list(map(int, i))
    B.append(i)

matrix_multiplication(num,A,B)
input4.close()

