#!/usr/bin/env python
# coding: utf-8

# In[4]:


file_read = open("input2.txt","r")
file_write = open("output2.txt","w")

x = file_read.readline().rstrip()
y = file_read.readline().rstrip()
z = file_read.readline().rstrip()

def LCS(x,y,z):
    m = len(x)+1
    n = len(y)+1
    o = len(z)+1

    c = [[[0]*(n) for i in range(m)]*(o) for j in range(m)]
    tracker = [[[None]*(n) for i in range(m)]*(o) for j in range(m)]

    max = 0
    for i in range(1,m):
        for j in range(1,n):
            for k in range(1,o):
                if x[i - 1] == y[j - 1] and x[i - 1] == z[k - 1]:
                    c[i][j][k] = 1 + c[i - 1][j - 1][k - 1]
                    tracker[i][j][k] = "diagonal"

                else:
                    if c[i - 1][j][k] >= c[i][j - 1][k]:
                        max = c[i - 1][j][k]
                        
                        if max >= c[i][j][k - 1]:                                
                            c[i][j][k] = max
                            tracker[i][j][k] = "up-up-left"
                        else:
                            max = c[i][j][k - 1]
                            c[i][j][k] = max
                            tracker[i][j][k] = "left-up-up"
                    else:
                        max = c[i][j - 1][k]
                        if max >= c[i][j][k - 1]:
                            c[i][j][k] = max
                            tracker[i][j][k] = "up-left-up"
                        else:
                            max = c[i][j][k - 1]
                            c[i][j][k] = max
                            tracker[i][j][k] = "left-up-up"

    return (c[len(c)-1][len(c)-1][len(c)-1])


#Finding the length of longest common sequence
LCS_length = LCS(x,y,z)
file_write.write(str(LCS_length))

file_read.close()
file_write.close()

