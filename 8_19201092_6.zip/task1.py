#!/usr/bin/env python
# coding: utf-8

# In[3]:


file_read = open("input1.txt","r")
file_write = open("output1.txt","w")

total_zones = file_read.readline()      #First line of input contains the total number of zones
row = file_read.readline().rstrip()     #Actual zone sequence of the match
column = file_read.readline().rstrip()  #Zone sequence predicted by MagneT

def LCS(row,column):
    
    x = len(row)+1     #Dummy index takes the first postition,hence length = len(row)+1
    y = len(column)+1  #Dummy index takes the first postition,hence length = len(column)+1

    c = [[0]*(y) for i in range(x)]    #works with integer values,hence 0 taken
    tracker = [[None]*(y) for i in range(x)]   #works with string(up,left,diagonal),hence None taken-->BACKTRACE MATRIX

    for i in range(1,x):
        for j in range(1,y):
            if row[i - 1] == column[j - 1]:
                c[i][j] = c[i - 1][j - 1] + 1
                tracker[i][j] = "diagonal"

            elif c[i - 1][j] >= c[i][j - 1]:                    
                c[i][j] = c[i - 1][j]
                tracker[i][j] = "up"

            else:
                c[i][j] = c[i][j - 1]
                tracker[i][j] = "left"
                
    return (c,tracker)

def LCS_sequence_print(tracker):
    position = tracker[len(tracker)-1][len(tracker)-1] 
    i = len(tracker)-1
    j = len(tracker)-1
    LCS_sequence = [] #This is in reverse order
    
    while position is not None:
        if position == "diagonal":
            LCS_sequence.append(i)
            position = tracker[i - 1][j - 1]
            i -= 1
            j -= 1
        elif position == "up":
            position = tracker[i - 1][j]
            i -= 1
        elif position == "left":
            position = tracker[i][j - 1]
            j -= 1

    
    return LCS_sequence

#column_t taken beacuse we are comparing the actual zone sequence(dependent) with the MagneT's predicted one(independent)
column_t = [[None, None],["Yasnaya", "Y"],["Pochinki", "P"],["School", "S"],["Rozhok", "R"],
            ["Farm", "F"],["Mylta", "M"],["Shelter", "H"],["Prison", "I"]]

function_call = LCS(row,column)
c = function_call[0]
tracker = function_call[1]

#PRINTING LONGEST COMMON ZONE SEQUENCE
a = LCS_sequence_print(tracker)
a.reverse()
for i in a:
    file_write.write(str(column_t[i][0]) + " ")

#CORRECTNESS
correctness = str((c[len(c)-1][len(c)-1])*100 // int(total_zones))
file_write.write("\nCorrectness of prediction: " + correctness + "%")

file_read.close()
file_write.close()

